<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$firstName = test_input($_POST["firstName"]);
	$lastName = test_input($_POST["lastName"]);
	$phoneNumber = test_input($_POST["phoneNumber"]);
	$email = test_input($_POST["email"]);
	$birthday = test_input($_POST["birthday"]);
	$occupation = test_input($_POST["occupation"]);
	$sport = test_input($_POST["sport"]);

	$_SESSION["firstName"] = $firstName;
	$_SESSION["lastName"] = $lastName;
	$_SESSION["phoneNumber"] = $phoneNumber;
	$_SESSION["email"] = $email;
	$_SESSION["birthday"] = $birthday;
	$_SESSION["occupation"] = $occupation;
	$_SESSION["sport"] = $sport;

	header("Location:Session2.php");
	exit();
}

function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Session 1</title>
	<style>
		header {
			background-color: lightblue;
			padding: 10px;
			text-align: center;
		}
		nav {
			float: left;
			width: 20%;
			height: 400px;
			background-color: lightgray;
			padding: 10px;
			box-sizing: border-box;
		}
		
		section {
			margin-left: 25%;
			height: 400px;
			background-color: grey;
			color: white;
			padding: 10px;
			box-sizing: border-box;
		}
	</style>
</head>
<body>
	<?php include 'Header.php';?>
	
	<nav>
		<ul>
			<li><a href="Input.php">Input</a></li><br><br>
			<li><a href="Session1.php">Session 1</a></li><br><br>
			<li><a href="Session2.php">Session 2</a></li>
		</ul>
	</nav>
	<section>
		
		

		<div>
			<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
				<label for="firstName">First Name:</label>
				<input type="text" id="firstName" name="firstName"><br>

				<label for="lastName">Last Name:</label>
				<input type="text" id="lastName" name="lastName"><br>

				<label for="phoneNumber">Phone Number:</label>
				<input type="tel" id="phoneNumber" name="phoneNumber"><br>

				<label for="email">Email:</label>
				<input type="email" id="email" name="email"><br>

				<label for="birthday">Birthday:</label>
				<input type="date" id="birthday" name="birthday"><br>

				<label for="occupation">Occupation:</label><br>
				<input type="radio" id="student" name="occupation" value="student">
				<label for="student">Student </label><br>

				<input type="radio" id="Part-time" name="occupation" value="Part-time">
            <label for="Part-time">Part-time</label><br>
            <input type="radio" id="Full-time" name="occupation" value="Full-time">
            <label for="Full-time">Full-time</label><br>
            <input type="radio" id="Internship" name="occupation" value="Internship">
            <label for="engineer">Internship</label><br>

			<label for="sports">Favorite Sport:</label>
			<select id="sports" name="sports">
				<option value="hockey">Hockey</option>
				<option value="football">Football</option>
				<option value="carling">Carling</option>
				<option value="tennis">Tennis</option>
			</select><br>

			<input type="submit" value="Submit">
		</form>
	</div>

	
</section>
<?php include 'Footer.php';?>
