<footer style="background-color: lightblue; text-align: center;" >
	<p>Student Number: 041070018</p>
	<p>First Name: Sahil</p>
	<p>Last Name: Kqkadiya</p>
	<p>Email: kaka0030@algonquinlive.com</p>
</footer>
</body>
</html>
