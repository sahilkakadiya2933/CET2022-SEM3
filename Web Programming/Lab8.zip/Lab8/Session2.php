<?php
session_start();

// Retrieve session variables
$firstName = $_SESSION["firstName"];
$lastName = $_SESSION["lastName"];
$phoneNumber = $_SESSION["phoneNumber"];
$email = $_SESSION["email"];
$birthday = $_SESSION["birthday"];
$occupation = $_SESSION["occupation"];
$sport = $_SESSION["sport"];
?>


<!DOCTYPE html>
<html>
<head>
	<title>Session 2</title>
	<style>
		header {
			background-color: lightblue;
			padding: 10px;
			text-align: center;
		}
		nav {
			float: left;
			width: 20%;
			height: 400px;
			background-color: lightgray;
			padding: 10px;
			box-sizing: border-box;
		}
	
		section {
			margin-left: 25%;
			height: 400px;
			background-color: grey;
			color: white;
			padding: 10px;
			box-sizing: border-box;
		}
	</style>
</head>
<body>
	<?php include 'Header.php';?>
	
	<nav>
		<ul>
			<li><a href="Input.php">Input</a></li><br><br>
			<li><a href="Session1.php">Session 1</a></li><br><br>
			<li><a href="Session2.php">Session 2</a></li>
		</ul>
	</nav>
	<section>

		<h2>Session 2</h2>
		<p>First Name: <?php echo $firstName; ?></p>
		<p>Last Name: <?php echo $lastName; ?></p>
		<p>Phone Number: <?php echo $phoneNumber; ?></p>
		<p>Email: <?php echo $email; ?></p>
		<p>Birthday: <?php echo $birthday; ?></p>
		<p>Occupation: <?php echo $occupation; ?></p>
		<p>Sport: <?php echo $sport; ?></p>
	
	</section>
	<?php include 'Footer.php';?>
</body>
</html>
