<!DOCTYPE html>
<html>
<head>
	<title>Input</title>
	<style>
		header {
			background-color: lightblue;
			padding: 10px;
			text-align: center;
		}
		nav {
			float: left;
			width: 20%;
			height: 600px;
			background-color: lightgray;
			padding: 10px;
			box-sizing: border-box;
		}
		
		section {
			margin-left: 25%;
			height: 600px;
			background-color: grey;
			color: white;
			padding: 10px;
			box-sizing: border-box;
		}
		.dem1{
			margin: 10px;
			margin-top: 40px;
			float: left;
		}
		.dem2{
			float: right	;
		}
	</style>
</head>
<body>
	<!-- Header -->
	<?php include 'Header.php';?>


	<!-- Menu -->
	<nav>
		<ul>
			<li><a href="Input.php">Input</a></li><br><br>
			<li><a href="Session1.php">Session 1</a></li><br><br>
			<li><a href="Session2.php">Session 2</a></li>
		</ul>
	</nav>
	

	<!-- Right Side Column -->
	<section>
	
    
    <div class="dem1">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="firstName">First Name:</label>
            <input type="text" id="firstName" name="firstName"><br>

            <label for="lastName">Last Name:</label>
            <input type="text" id="lastName" name="lastName"><br>

            <label for="phoneNumber">Phone Number:</label>
            <input type="tel" id="phoneNumber" name="phoneNumber"><br>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email"><br>

            <label for="birthday">Birthday:</label>
            <input type="date" id="birthday" name="birthday"><br>

            <label for="occupation">Occupation:</label><br>
            <input type="radio" id="Student" name="occupation" value="Student">
            <label for="student">Student </label><br>

            <input type="radio" id="Part-time" name="occupation" value="Part-time">
            <label for="Part-time">Part-time</label><br>
            <input type="radio" id="Full-time" name="occupation" value="Full-time">
            <label for="Full-time">Full-time</label><br>
            <input type="radio" id="Internship" name="occupation" value="Internship">
            <label for="engineer">Internship</label><br>

            <label for="sports">Favorite Sport:</label>
            <select id="sports" name="sports">
                <option value="hockey">Hockey</option>
                <option value="football">Football</option>
                <option value="carling">Chess</option>
                <option value="tennis">Tennis</option>
            </select><br>

           <br> <input type="submit" value="Submit">
        </form>
    </div>
    <div class="dem2">
	<?php 
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$firstName = $lastName = $phoneNumber = $email = $birthday = $occupation = $sports = "";
	
		// Validate first name
		if (empty($_POST["firstName"])) {
			$firstNameErr = "First name is required";
		} else {
			$firstName = test_input($_POST["firstName"]);
			// Check if name only contains letters and whitespace
			if (!preg_match("/^[a-zA-Z ]*$/",$firstName)) {
				$firstNameErr = "Only letters and white space allowed";
			}
		}
	
		// Validate last name
		if (empty($_POST["lastName"])) {
			$lastNameErr = "Last name is required";
		} else {
			$lastName = test_input($_POST["lastName"]);
			// Check if name only contains letters and whitespace
			if (!preg_match("/^[a-zA-Z ]*$/",$lastName)) {
				$lastNameErr = "Only letters and white space allowed";
			}
		}
	
		// Validate phone number
		if (empty($_POST["phoneNumber"])) {
			$phoneNumberErr = "Phone number is required";
		} else {
			$phoneNumber = test_input($_POST["phoneNumber"]);
			// Check if phone number is valid
			if (!preg_match("/^[0-9]*$/",$phoneNumber)) {
				$phoneNumberErr = "Invalid phone number";
			}
		}
	
		// Validate email
		if (empty($_POST["email"])) {
			$emailErr = "Email is required";
		} else {
			$email = test_input($_POST["email"]);
			// Check if email address is valid
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
				$emailErr = "Invalid email format";
			}
		}
	
		// Validate birthday
		if (empty($_POST["birthday"])) {
			$birthdayErr = "Birthday is required";
		} else {
			$birthday = test_input($_POST["birthday"]);
		}
	
		// Validate occupation
		if (isset($_POST["occupation"])) {
			$occupation = test_input($_POST["occupation"]);
		} else {
			$occupationErr = "Occupation is required";
		}
	
		// Validate favorite sport
		if (empty($_POST["sports"])) {
			$sportsErr = "Favorite sport is required";
		} else {
			$sports = test_input($_POST["sports"]);
		}
	
		// Display the form data or error messages
		if (empty($firstNameErr) && empty($lastNameErr) && empty($phoneNumberErr) && empty($emailErr) && empty($birthdayErr) && empty($occupationErr) && empty($sportsErr)) {
			echo "<h2>Form Data:</h2>";
			echo "<p>First Name: " . $firstName . "</p>";
			echo "<p>Last Name: " . $lastName . "</p>";
			echo "<p>Phone Number: " . $phoneNumber . "</p>";
			echo "<p>Email: " . $email . "</p>";
			echo "<p>Birthday: " . $birthday . "</p>";
			echo "<p>Occupation: " . $occupation . "</p>";
			echo "<p>Favorite Sport: " . $sports . "</p>";
		}

    }
    ?>
    </div>
	</div>
</section>


<?php include 'Footer.php';?>
