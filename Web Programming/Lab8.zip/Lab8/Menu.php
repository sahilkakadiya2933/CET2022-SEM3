<!DOCTYPE html>
<html>
<head>
	<title>Web Page</title>
	<style>
		
		nav {
			float: left;
			width: 20%;
			height: 400px;
			background-color: lightcyan;
			padding: 10px;
			box-sizing: border-box;
		}
		
		section {
			margin-left: 25%;
			height: 400px;
			background-color: grey;
			color: white;
			padding: 10px;
			box-sizing: border-box;
		}
	</style>
</head>
<body>
	
	<nav>
		<ul>
			<li><a href="input.php">Input</a></li><br><br>
			<li><a href="Session1.php">Session 1</a></li><br><br>
			<li><a href="Session2.php">Session 2</a></li>
		</ul>
	</nav>
	<section>
		
	</section>
</body>
</html>
