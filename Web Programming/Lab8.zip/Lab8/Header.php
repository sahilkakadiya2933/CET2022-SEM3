<!DOCTYPE html>
<html>
<head>
	<title>Lab8</title>
</head>
<style type="text/css">
	
</style>
<body>
	<header style="background-color: lightpink; text-align: center;">
	<h1>Computer Engineering Technology - Computing Science</h1>
	<h2>Web Programming</h2>
</header>

