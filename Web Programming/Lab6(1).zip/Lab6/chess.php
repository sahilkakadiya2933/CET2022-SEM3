<html>
	<head>
		<link rel="stylesheet" type="text/css" href="StyleSheet.css" />
	</head>
<body>
<?php
    include('Header.php'); 
    include('Menu.php');
?>

<table border="1">
    <?php
        for($row=1;$row<=8;$row++)
        {
            echo "<tr>";
            for($col=1;$col<=8;$col++)
            {
                $sum=$row+$col;
                if($sum%2==0)
                {
                    echo "<td height=40px width=40px bgcolor=#FFFFFF></td>";
                }
                else
                {
                    echo "<td height=40px width=40px bgcolor=#000000></td>";
                }
            }
            echo "</tr>";
        }
    ?>
</table>

<?php
    include('Footer.php');
?>
</body>
</html>