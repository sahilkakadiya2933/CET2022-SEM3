<!DOCTYPE html>
<html>
<body>

<?php
	echo '<a href ="chess.php">Chess Board</a><br><br>';
    echo '<a href ="Random.php">Random</a><br><br>';
    echo '<a href ="Pattern.php">Pattern</a><br>';
?>

</body>
</html>
