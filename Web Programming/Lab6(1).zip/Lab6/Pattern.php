<html>
	<head>
		<link rel="stylesheet" type="text/css" href="StyleSheet.css" />
	</head>
<body>
<?php
	include 'Header.php';
	include 'Menu.php';

	echo "<h1>Pattern</h1>";

	for ($i = 1; $i <= 17; $i++) {
		if ($i <= 9) {
			for ($j = 1; $j <= $i; $j++) {
				echo "*";
			}
		} else {
			for ($j = 1; $j <= (17 - $i); $j++) {
				echo "*";
			}
		}
		echo "<br>";
	}

	include 'Footer.php';
?>
</body>
</html>
