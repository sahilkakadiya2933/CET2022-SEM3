<html>
<head>
	<title>First Page</title>
	<link rel="stylesheet" type="text/css" href="StyleSheet.css" />
</head>
<body>
<?php
    // Include header
    include 'Header.php';
?>


<?php
    // Include menu
    include 'Menu.php';
?>

<?php
    // Include footer
    include 'Footer.php';
?>
</body>
</html>
