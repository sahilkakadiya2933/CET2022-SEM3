<html>
	<head>
		<link rel="stylesheet" type="text/css" href="StyleSheet.css" />
	</head>
<body>
<?php
	include 'Header.php';
	include 'Menu.php';

	echo "<h1>Random Numbers</h1>";

	
	$range1 = 0;
	$range2 = 0;
	$range3 = 0;
	$range4 = 0;
	$range5 = 0;

	for ($i = 1; $i <= 500; $i++) {
		$numbers = rand(1, 50);
		if ($numbers >= 1 && $numbers <= 10) {
			$range1++;
		} elseif ($numbers >= 11 && $numbers <= 20) {
			$range2++;
		} elseif ($numbers >= 21 && $numbers <= 30) {
			$range3++;
		} elseif ($numbers >= 31 && $numbers <= 40) {
			$range4++;
		} else {
			$range5++;
		}
	}

	// Display the total number of values in each range
	echo "<p>Range 1: $range1</p>";
	echo "<p>Range 2: $range2</p>";
	echo "<p>Range 3: $range3</p>";
	echo "<p>Range 4: $range4</p>";
	echo "<p>Range 5: $range5</p>";

	// Calculate the percentage of values in each range
	$percentage1 = round(($range1 / 500) * 100);
	$percentage2 = round(($range2 / 500) * 100);
	$percentage3 = round(($range3 / 500) * 100);
	$percentage4 = round(($range4 / 500) * 100);
	$percentage5 = round(($range5 / 500) * 100);

	// Display the histogram of stars
	echo "<p>Range 1: ";
	for ($i = 1; $i <= $percentage1; $i++) {
		echo "*";
	}
	echo "</p>";

	echo "<p>Range 2: ";
	for ($i = 1; $i <= $percentage2; $i++) {
		echo "*";
	}
	echo "</p>";

	echo "<p>Range 3: ";
	for ($i = 1; $i <= $percentage3; $i++) {
		echo "*";
	}
	echo "</p>";

	echo "<p>Range 4: ";
	for ($i = 1; $i <= $percentage4; $i++) {
		echo "*";
	}
	echo "</p>";

	echo "<p>Range 5: ";
	for ($i = 1; $i <= $percentage5; $i++) {
		echo "*";
	}
	echo "</p>";

	include 'Footer.php';
?>
</body>
</html>