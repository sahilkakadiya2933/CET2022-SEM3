<html>
	<head>
		<link rel="stylesheet" type="text/css" href="StyleSheet.css" />
	</head>
<body>
<?php
	echo "<div id=\"header\"><h1>Computer Engineering Technology - Computing Science</h1>
	<h1> Web Programming</h1></div>";
?>

</body>
</html>
