<?php include 'Header.php'; ?>

<!DOCTYPE html>
<html>
<head>
	<title>Books</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<style>
		#menu{
        background-color: black;
		padding-top: 50px;
    	}

		

	div{
		background-color: black;
		display: inline-block;
		padding: 60px;
		vertical-align: middle;
		color: white;
		padding-right: auto;


	}

		input{
			background: white;
		}


		.error {
			color: red;
		}
	</style>

<script>
		function getBooks() {
			var category = $('#category').val();
			if (category == "") {
				$('#result').html("<p>Please select a category.</p>");
			} else {
				$.ajax({
					type: "GET",
					url: "books.php",
					data: {category: category},
					success: function(result) {
						$('#result').html(result);
					},
					error: function() {
						$('#result').html("<p>Error fetching books.</p>");
					}
				});
			}
		}
	</script>
</head>
<body>
	<div>
		<div id = "menu">
			<br>
			<?php include 'Menu.php'; ?>
		</div>
	</div>
	

	<div>
		<div id="form">
			<form>
				<label for="Select a book category:">Select a book category:</label>
				<select id="category">
					<option value="">Select Book Category</option>
					<option value="Computer Science">Computer Science</option>
					<option value="Fantasy">Fantasy</option>
					<option value="Romance">Romance</option>
					<option value="Horror">Horror</option>
					<option value="Science Fiction">Science Fiction</option>
				</select>
				<input type="button" value="Submit" onclick="getBooks();">
			</form>
			<div id="result"> </div>
			<script src="books.js"></script>

		</div>
	</div>

</body>
</html>

<?php include 'Footer.php'; ?> 
















<?php
if(isset($_GET['category'])) {
    $category = $_GET['category'];
    $xml = simplexml_load_file('C:\EasyPHP\lab10\Books\Books.xml');
    $books = $xml->xpath("//book[genre='$category']");
    if (count($books) > 0) {
        echo "<table>";
        echo "<tr><th>Title</th><th>Author</th><th>Category</th><th>Price</th></tr>";
        foreach ($books as $book) {
            echo "<tr>";
            echo "<td>" . $book->title . "</td>";
            echo "<td>" . $book->author . "</td>";
            echo "<td>" . $book->genre . "</td>";
            echo "<td>" . $book->price . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No books found in the selected category.</p>";
    }
}
?>






