
<?php
if(isset($_GET['category'])) {
	$category = $_GET['category'];
	$xml = simplexml_load_file('C:\EasyPHP\lab10\Books\Books.xml');
	$books = $xml->xpath("//book[category='$category']");
	if (count($books) > 0) {
		echo "<table>";
		echo "<tr><th>Title</th><th>Author</th><th>Category</th><th>Price</th></tr>";
		foreach ($books as $book) {
			echo "<tr>";
			echo "<td>" . $book->author . "</td>";
            echo "<td>" . $book->title . "</td>";
			echo "<td>" . $book->genre . "</td>";
			echo "<td>" . $book->price . "</td>";
            echo "<td>" . $book->publish_data . "</td>";
            echo "<td>" . $book->description . "</td>";
			echo "</tr>";
		}
		echo "</table>";
	}
