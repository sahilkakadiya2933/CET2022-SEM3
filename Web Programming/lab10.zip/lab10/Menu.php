<!DOCTYPE html>
<html>
<head>
	<style>
	#menu{
		padding: auto;
		display: block;
		color: white;
	}
	a{
		color: white;
	}
	</style>
	
</head>
<body>
	<menu id="menu">
		<a href="lab10.php">Lab 10</a>
	</menu>