

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; 
      charset=UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="">
      <meta name="author" content="">
      <title>Book Template</title>

      <link rel="shortcut icon" href="../../assets/ico/favicon.png">   

      <!-- Bootstrap core CSS -->
      <link href="bootstrap3_bookTheme/dist/css/bootstrap.min.css" rel="stylesheet">
      <!-- Bootstrap theme CSS -->
      <link href="bootstrap3_bookTheme/theme.css" rel="stylesheet">


      <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
      <!--[if lt IE 9]>
      <script src="bootstrap3_bookTheme/assets/js/html5shiv.js"></script>
      <script src="bootstrap3_bookTheme/assets/js/respond.min.js"></script>
      <![endif]-->
   </head>

   <body>

      <?php include 'includes/book-header.inc.php'; ?>
         
      <div class="container">
         <div class="row">  <!-- start main content row -->

            <div class="col-md-2">  <!-- start left navigation rail column -->
               <?php include 'includes/book-left-nav.inc.php'; ?>
            </div>  <!-- end left navigation rail --> 

            <div class="col-md-6">  <!-- start main content column -->
            
               <!-- book panel  -->
               <div class="panel panel-danger spaceabove">           
               <div class="panel-heading"><h4> </h4></div>
               <table class="table">
                  <tr>
                     <th>Cover</th>
                     <th>ISBN</th>
                     <th>Title</th>
                  </tr>
                  
               </table>
               <?php
      // Establish database connection
      $host = "localhost"; // Replace with your database host
$username = "umayjcpi5ehla"; // Replace with your database username
$password = "Sahil@123"; // Replace with your database password
$dbname = "dblgzv8leq0giu"; // Replace with your database name
$conn = new mysqli($host, $username, $password, $dbname);

      if ($conn->connect_error) {
         die("Connection failed: " . $conn->connect_error);
      }
      // Retrieve book data from database
      $sql = "SELECT * FROM books";
      $result = $conn->query($sql);
      ?>

      <?php
      // Display book data in a table format with links to book-details.php page
      echo "<div class='panel panel-danger spaceabove'>";
      echo "<div class='panel-heading'><h4>Books</h4></div>";
      echo "<table class='table'>";
      echo "<tr><th>Cover</th><th>ISBN</th><th>Title</th></tr>";
      while ($row = $result->fetch_assoc()) {
         echo "<tr>";
         echo "<td><img src='book-covers/{$row['isbn']}.jpg' class='img-thumbnail' width='100'></td>";
         echo "<td>{$row['isbn']}</td>";
         echo "<td><a href='book-details.php?isbn={$row['isbn']}'>{$row['title']}</a></td>";
         echo "</tr>";
      }
      echo "</table>";
      echo "</div>";
      ?>

      <?php
      // Retrieve Categories, Imprints, Status, and BindingTypes from database
      $sql_categories = "SELECT DISTINCT category FROM subcategories";
      $result_categories = $conn->query($sql_categories);

      $sql_imprints = "SELECT * FROM imprints";
      $result_imprints = $conn->query($sql_imprints);

      $sql_statuses = "SELECT * FROM production_statuses";
      $result_statuses = $conn->query($sql_statuses);

      $sql_bindings = "SELECT * FROM binding_types";
      $result_bindings = $conn->query($sql_bindings);

      // Display lists of Categories, Imprints, Status, and BindingTypes
      echo "<div class='col-md-2'>";
      echo "<div class='panel panel-info spaceabove'>";
      echo "<div class='panel-heading'><h4>Categories</h4></div>";
      echo "<ul class='nav nav-pills nav-stacked'>";
      while ($row = $result_categories->fetch_assoc()) {
         echo "<li><a href='book-list.php?category={$row['category']}'>{$row['category']}</a></li>";
      }
      echo "</ul>";
      echo "</div>";

      echo "<div class='panel panel-info spaceabove'>";
      echo "<div class='panel-heading'><h4>Imprints</h4></div>";
      echo "<ul class='nav nav-pills nav-stacked'>";
      while ($row = $result_imprints->fetch_assoc()) {
         echo "<li><a href='book-list.php?imprint_id={$row['imprint_id']}'>{$row['imprint']}</a></li>";
      }
      echo "</ul>";
      echo "</div>";
      ?>
      </div>
               </div>
            </div>
            
            <div class="col-md-2">  <!-- start left navigation rail column -->
               <div class="panel panel-info spaceabove">
                  <div class="panel-heading"><h4>Categories</h4></div>
                     <ul class="nav nav-pills nav-stacked">
                        
                  </ul> 
               </div>
                     
            </div>  <!-- end left navigation rail --> 
            
            <div class="col-md-2">  <!-- start left navigation rail column -->
               <div class="panel panel-info spaceabove">
                  <div class="panel-heading"><h4>Imprints</h4></div>
                  <ul class="nav nav-pills nav-stacked">
                     
                  </ul>
               </div>    

               <div class="panel panel-info">
                  <div class="panel-heading"><h4>Status</h4></div>
                  <ul class="nav nav-pills nav-stacked">
                     
                  </ul>
               </div>  
               
               <div class="panel panel-info">
                  <div class="panel-heading"><h4>Binding</h4></div>
                  <ul class="nav nav-pills nav-stacked">
                     
                  </ul>
               </div>           
            </div>  <!-- end left navigation rail -->       


            </div>  <!-- end main content column -->
         </div>  <!-- end main content row -->
      </div>   <!-- end container -->
         


         
         
      <!-- Bootstrap core JavaScript
      ================================================== -->
      <!-- Placed at the end of the document so the pages load faster -->
      <script src="bootstrap3_bookTheme/assets/js/jquery.js"></script>
      <script src="bootstrap3_bookTheme/dist/js/bootstrap.min.js"></script>
      <script src="bootstrap3_bookTheme/assets/js/holder.js"></script>
   </body>
</html>