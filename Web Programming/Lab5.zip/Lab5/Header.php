<!DOCTYPE html>
<html>
<body>

<?php
	echo "<div id=\"header\"><h1>Computer Engineering Technology - Computing Science</h1>
	<h1> Web Programming</h1></div>";
?>

</body>
</html>
