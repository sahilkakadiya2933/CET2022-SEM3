<?php
$firstName = "Sahil";
$lastName = "Kakadiya";
$anothorString = "This is the first time I am using PHP!!";
?>
<html>
	<head>
		<title>Include Example</title>
		<link rel="stylesheet" type="text/css" href="StyleSheet.css" />
	</head>
	<body>
			<?php include_once "Header.php" ?>
			<?php include_once "Menu.php" ?>
			<?php
				echo "
				<p> My name is : ".$firstName." ".$lastName."</p>
				<p> My student Number is : 041052919 </p>
				<p> The concatenated text is 	Hello World!! ".$anothorString."</P>";
    	 
    	
				$str = "Hello World!! This is the first time I am using PHP!!";
				$len = strlen($str);
				echo "<p> The length of the concatenated text is Hello World!! ".$anothorString." is: ".$len."</p>";		
   		 

		
				$str2 = "Hello World!! This is the first time I am using PHP!!";
				$position = strpos($str2, "PHP");	
				echo "<p>The position of the word PHP is: ".$position."</p>";	
			?>
			<?php include_once "Footer.php" ?>
	</body>
</html>