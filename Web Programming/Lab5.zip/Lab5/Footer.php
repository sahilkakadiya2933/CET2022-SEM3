<?php
$firstName = "Sahil";
$lastName = "Kakadiya";
define("Numbers","041052919")
?>
<!DOCTYPE html>
<html>
<body>

<?php
	echo "<div id=\"footer\">
	<p> Name: ".$firstName." ".$lastName."</p>
	<p> Student Number: ",Numbers," <p> </br>
	</div>";
?>

</body>
</html>
