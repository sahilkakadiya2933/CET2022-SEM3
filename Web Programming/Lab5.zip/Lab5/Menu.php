<!DOCTYPE html>
<html>
<body>

<?php
	echo '<a href ="https://sahilk.sgedu.site/Lab2/index.html">Lab2</a><br><br>';
    echo '<a href ="https://sahilk.sgedu.site/Lab3/index.html">Lab3</a><br><br>';
    echo '<a href ="https://sahilk.sgedu.site/Lab4/index.html">Lab4</a><br>';
?>

</body>
</html>
