<?php
$firstName = "Sahil";
$lastName = "Kakadiya";
$anothorString = "This is the first time I am using PHP!!";
define("Numbers","041052919")
?>
<html>
<body>
	<?php
	echo "
			<p> My name is : ".$firstName." 	".$lastName."</p>
			<p> My student Number is : ",Numbers," </p>
			<p> The concatenated text is 	Hello World!! ".$anothorString."</P>";
     ?>
     <?php
	$str = "Hello World!! This is the first time I am using PHP!!";
	$len = strlen($str);
	echo "<p> The length of the concatenated text is Hello World!! ".$anothorString." is: ".$len."</p>";		
    ?>

	<?php
	$str2 = "Hello World!! This is the first time I am using PHP!!";
	$position = strpos($str2, "PHP");	
	echo "<p>The position of the word PHP is: ".$position."</p>";	
    ?>


	
	
            
</body>
</html>