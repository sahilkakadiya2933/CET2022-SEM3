<?php
// Check if the user is logged in and is a Manager
session_start();
if (!isset($_SESSION['email']) || $_SESSION['admin_code'] != 999) {
	// Redirect the user to the login page
	header("Location: Login.php");
	exit();
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin Page</title>
</head>
<body>
	<?php include("Header.php"); ?>
	<?php include("Menu.php"); ?>
	<h1>Welcome Manager!</h1>
	<p>You have successfully logged in as a Manager.</p>
	<a href="SelectAccount.php">Edit an employee's account</a>
	<?php include("Footer.php"); ?>
</body>
</html>
