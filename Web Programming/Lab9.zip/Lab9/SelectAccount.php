<?php
session_start();

$email = $_POST["email"];
$password = $_POST["password"];
$admin_code = $_POST["admin_code"];

// Create a connection to the database
$host = "localhost";
$database = "your_database";
$username = "your_username";
$password_db = "your_password";

$conn = mysqli_connect($host, $username, $password_db, $database);

// Check if the connection is successful
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Create a SQL query to check if the user is a manager
$sql = "SELECT * FROM Employee WHERE EmailAddress='$email' AND Password='$password' AND AdminCode='$admin_code'";

// Execute the query
$result = mysqli_query($conn, $sql);

// Check if there is one row returned, indicating that the user is a manager
if (mysqli_num_rows($result) == 1) {
  // Store the user's information in the session
  $row = mysqli_fetch_assoc($result);
  $_SESSION['email'] = $row['EmailAddress'];
  $_SESSION['admin_code'] = $row['AdminCode'];
} else {
  // If the user is not a manager, redirect to the Admin.php page
  header("Location: Admin.php");
  exit();
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Select Employee Account</title>
</head>
<body>
	<?php include("Header.php"); ?>
	<?php include("Menu.php"); ?>
	<h1>Select Employee Account</h1>
	<form action="UpdateAccount.php" method="POST">
		<p>Please select an employee to edit:</p>
		<select name="employeeId">
			<option value="">--Select--</option>
			<?php
			// Create a connection to the database
			$host = "localhost";
			$database = "your_database";
			$username = "your_username";
			$password_db = "your_password";

			$conn = mysqli_connect($host, $username, $password_db, $database);

			// Check if the connection is successful
			if (!$conn) {
				die("Connection failed: " . mysqli_connect_error());
			}

			// Create a SQL query to get all rows from the Employee table
			$sql = "SELECT EmployeeId, FirstName, LastName FROM Employee";

			// Execute the query
			$result = mysqli_query($conn, $sql);

			// Check if there are any rows returned
			if (mysqli_num_rows($result) > 0) {
				while ($row = mysqli_fetch_assoc($result)) {
					echo "<option value='" . $row['EmployeeId'] . "'>" . $row['FirstName'] . " " . $row['LastName'] . "</option>";
				}
			}

			// Close the database connection
			mysqli_close($conn);
			?>
		</select><br><br>
		<input type="submit" value="Edit Employee">
	</form>
	<?php include("Footer.php"); ?>
</body>
</html>

<?php
if (!isset($_SESSION['email']) || $_SESSION['admin_code'] !== '999') {
	// Redirect the user to the login page
	header("Location: Login.php");
	exit();
}

// Create a connection to the database
$host = "localhost";
$database = "your_database";
$username = "your_username";
$password_db = "your_password";

$conn = mysqli_connect($host, $username, $password_db, $database);

// Check if the connection is successful
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	// Retrieve the form data
	$employeeId = $_POST['employeeId'];
	$firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
	$emailAddress = $_POST['emailAddress'];
	$telephoneNumber = $_POST['telephoneNumber'];
	$socialInsuranceNumber = $_POST['socialInsuranceNumber'];
	$designation = $_POST['designation'];

	// Update the corresponding row in the Employee table
	$sql = "UPDATE Employee SET FirstName='$firstName', LastName='$lastName', EmailAddress='$emailAddress', TelephoneNumber='$telephoneNumber', SocialInsuranceNumber='$socialInsuranceNumber', Designation='$designation' WHERE EmployeeId=$employeeId";

	$result = mysqli_query($conn, $sql);

	if (mysqli_affected_rows($conn) > 0) {
		// Redirect the Manager to the UpdateComplete.php page with a success message
		header("Location: UpdateComplete.php?message=success");
		exit();
	} else {
		// Redirect the Manager to the UpdateComplete.php page with an error message
		header("Location: UpdateComplete.php?message=error");
		exit();
	}
}

// Retrieve the selected employee's information from the database
$employeeId = $_GET['employeeId'];

$sql = "SELECT * FROM Employee WHERE EmployeeId=$employeeId";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) === 0) {
	// Redirect the Manager to the SelectAccount.php page with an error message
	header("Location: SelectAccount.php?message=error");
	exit();
}

$row = mysqli_fetch_assoc($result);

mysqli_close($conn);
?>


