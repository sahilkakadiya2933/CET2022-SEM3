<!DOCTYPE html>
<html>
<head>
	<title>View All Employees</title>
</head>
<body>
	<?php include("Header.php"); ?>
	<?php include("Menu.php"); ?>
	<h1>View All Employees</h1>
	<?php
	// Check if the user is logged in
	session_start();
	if (!isset($_SESSION['email'])) {
		// Redirect the user to the login page
		header("Location: Login.php");
		exit();
	}

	// Create a connection to the database
	$host = "localhost";
	$database = "your_database";
	$username = "your_username";
	$password_db = "your_password";

	$conn = mysqli_connect($host, $username, $password_db, $database);

	// Check if the connection is successful
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}

	// Create a SQL query to get all rows from the Employee table
	$sql = "SELECT EmployeeId, FirstName, LastName, EmailAddress, TelephoneNumber, SocialInsuranceNumber, Designation FROM Employee";

	// Execute the query
	$result = mysqli_query($conn, $sql);

	// Check if there are any rows returned
	if (mysqli_num_rows($result) > 0) {
		// Display the results in an HTML table
		echo "<table border='1'>";
		echo "<tr><th>Employee ID</th><th>First Name</th><th>Last Name</th><th>Email Address</th><th>Telephone Number</th><th>Social Insurance Number</th><th>Designation</th></tr>";
		while ($row = mysqli_fetch_assoc($result)) {
			echo "<tr><td>".$row['EmployeeId']."</td><td>".$row['FirstName']."</td><td>".$row['LastName']."</td><td>".$row['EmailAddress']."</td><td>".$row['TelephoneNumber']."</td><td>".$row['SocialInsuranceNumber']."</td><td>".$row['Designation']."</td></tr>";
		}
		echo "</table>";
	} else {
		// Display a message if there are no rows returned
		echo "No employees found.";
	}

	// Close the database connection
	mysqli_close($conn);
	?>
	<?php include("Footer.php"); ?>
</body>
</html>
