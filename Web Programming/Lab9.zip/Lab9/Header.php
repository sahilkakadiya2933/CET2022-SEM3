<!DOCTYPE html>
<html>
<head>
	<title>Web Programming</title>
	<style>
		#header{
			background: grey;
			text-align:center;
			padding-top: 1%;
			padding-bottom: 2%;
			color: white;
		}
		
	</style>
</head>
<body>
	<header id="header">
		<h1>Computer Engineering Technology - Computing Science</h1>
	</header>
	
	
</body>
</html>
