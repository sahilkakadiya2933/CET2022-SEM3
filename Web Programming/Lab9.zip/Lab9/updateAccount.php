<?php include 'Header.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
	<style>
		.container{
			background: #FFEFD5;
			color: black;
			padding-bottom: 2%;
			height: 380px;
			
		}

		input{
			background: white;
		}

		.row {
			display: grid;
			grid-template-columns: 400px 500px;
	
		}
	
		.column1 {
		
			padding: 16px;
	  		height: 500px;
			
		}

		.column2 {
			
			padding: 16px;
	  		height: 250px;
		}
	</style>
</head>
<body>

	<div class="container">
		<div class="row">
			<div class="coloumn1">
				<br>
				<?php include 'Menu.php'; ?>
			</div>

			<div class="coloumn2">	
				<h1>Admin Panel</h1>
				<form action="login.php" method="POST">
					<label for="firstname">First Name:</label>
					<input type="firstname" id="firstname" name="firstname" required><br><br>

					<label for="lastname">Last Name:</label>
					<input type="lastname" id="lastname" name="lastname" required><br><br>

					<label for="emailaddress">Email Address:</label>
					<input type="emailaddress" id="emailaddress" name="emailaddress" required><br><br>

					<label for="phone number">Phone Number:</label>
					<input type="phone number" id="phone number" name="phone number" required><br><br>

					<label for="designation">Designation:</label>
					<input type="designation" id="designation" name="designation" required><br><br>

					<label for="admincode">Admin Code</label>
					<input type="admincode" id="admincode" name="admincode" required><br><br>

					<input style="background: #C0C0C0;"type="submit" value="Update Record">
				</form>
				
			</div>
		</div>
	</div>

</body>
</html>
<?php include('Footer.php'); 
