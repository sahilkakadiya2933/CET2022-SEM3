<!DOCTYPE html>
<html>
<head>
	<style>
		#footer{
			background: grey;
			text-align:center;
			padding-top: 1%;
			padding-bottom: 1%;
			color: white;
		}
		
	</style>
</head>
<body>
	<footer id="footer">
		<p>Student Number: 041052919</p>
		<p>First Name: Sahil Pareshbhai</p>
		<p>Last Name: Kakadiya</p>
		<p>Email Address: kaka0030@algonquinlive.com</p>
	</footer>
</body>
</html>
