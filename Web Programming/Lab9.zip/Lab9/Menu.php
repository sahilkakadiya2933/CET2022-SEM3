<!DOCTYPE html>
<html>
<head>
	
</head>
<body>
	<menu id="menu">

		<ul>
			<li><a href="CreateAccount.php">Create Account</a></li><br>
			<li><a href="Login.php">Login</a></li><br>
			<li><a href="ViewAllEmployees.php">View All Employees</a></li><br>
			<li><a href="SelectAccount.php">Select Account</a></li>
		</ul>

	</menu>