<?php
// Start the session
session_start();

// Check if the user is already logged in, redirect to ViewAllEmployees.php
if (isset($_SESSION["email"])) {
  header("Location: ViewAllEmployees.php");
  exit;
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Connect to the database
  $servername = "localhost";
  $username = "username";
  $password = "password";
  $dbname = "myDB";

  $conn = new mysqli($servername, $username, $password, $dbname);

  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Get form data
  $email = $_POST["email"];
  $password = $_POST["password"];

  // Check if the user exists in the database
  $sql = "SELECT * FROM Employee WHERE email='$email' AND password='$password'";
  $result = $conn->query($sql);

  if ($result->num_rows == 1) {
    // Set session variables
    $row = $result->fetch_assoc();
    $_SESSION["email"] = $row["email"];
    $_SESSION["designation"] = $row["designation"];
    $_SESSION["admincode"] = $row["admin_code"];

    // Redirect to ViewAllEmployees.php
    header("Location: ViewAllEmployees.php");
    exit;
  } else {
    // Display error message
    $error_message = "Invalid email or password.";
  }

  // Close database connection
  $conn->close();
}
?>

<?php include 'Header.php'; ?>

<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<style>
		.container{
			background: #FFEFD5;
			color: black;
			padding-bottom: 2%;
			height: 380px;
		}

		input{
			background: white;
		}

		.row {
			display: grid;
			grid-template-columns: 400px 500px;
		}
	
		.column1 {
			padding: 16px;
	  		height: 150px;
		}

		.column2 {
			padding: 16px;
	  		height: 150px;
		}

		.error {
			color: red;
		}
	</style>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="coloumn1">
				<br>
				<?php include 'Menu.php'; ?>
			</div>

			<div class="coloumn2">
				<h1>Login</h1>
				<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
					<label for="email">Email Address:</label>
					<input type="email" id="email" name="email" required><br><br>

					<label for="password">Password:</label>
					<input type="password" id="password" name="password" required><br><br>

					<input style="background: Gainsboro	;" type="submit" value="Login">
				</form>

				<?php if (isset($error_message)) { ?>
				  <p class="error"><?php echo $error_message; ?></p>
				<?php } ?>
			</div>
		</div>
	</div>
</body>
</html>

<?php include 'Footer.php'; ?> 