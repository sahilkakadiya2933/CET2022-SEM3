<?php include 'Header.php'; ?>

<!DOCTYPE html>
<html>
<head>
	<title>Create Employee Account</title>
	<style>
		.container{
			background: #FFEFD5;
			color: black;
			padding-bottom: 2%;
			
		}

		input{
			background: white;
		}

		.row {
			display: grid;
			grid-template-columns: 400px 500px;
	
		}
	
		.column1 {
		
			padding: 16px;
	  		height: 250px;
			
		}

		.column2 {
			
			padding: 16px;
	  		height: 250px;
		}


	</style>
</head>
<body>
	
	<div class="container">
		<div class="row">
			<div class="coloumn1">
				<br>
				<?php include 'Menu.php'; ?>
			</div>

			<div class="coloumn2">

				<h1>Create your new account</h1>
				<form action="createAccount.php" method="POST">
					<strong>
					<p>Please fill in all information</p>
					<label for="firstname">First Name:</label>
					<input type="text" id="firstname" name="firstname" required><br><br>
					<label for="lastname">Last Name:</label>
					<input type="text" id="lastname" name="lastname" required><br><br>

					<label for="email">Email Address:</label>
					<input type="email" id="email" name="email" required><br><br>

					<label for="telephone">Telephone Number:</label>
					<input type="tel" id="telephone" name="telephone" required><br><br>

					<label for="sin">Social Insurance Number:</label>
					<input type="text" id="sin" name="sin" required><br><br>

					<label for="password">Password:</label>
					<input type="password" id="password" name="password" required><br><br>

					<label for="designation">Designation:</label>
					<select style="background: white;" id="designation" name="designation">
						<option value=""></option>
						<option value="ITDeveloper">IT Developer</option>
						<option value="Manager">Manager</option>
					</select><br><br>

					<label for="admincode">Admin Code:</label>
					<input type="text" id="admincode" name="admincode" required><br><br>
					</strong>
					<input style="background: Gainsboro	;" type="submit" value="Submit Information" >
				</form>
			</div>
		</div>
	</div>
</body>
</html>
<?php include('Footer.php'); ?>

<?php
// Connect to the database
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get form data
$firstname = $_POST["firstname"];
$lastname = $_POST["lastname"];
$email = $_POST["email"];
$telephone = $_POST["telephone"];
$sin = $_POST["sin"];
$password = $_POST["password"];
$designation = $_POST["designation"];
$admincode = $_POST["admincode"];

// Determine the admin code based on the designation
if ($designation == "ITDeveloper") {
  $admin_code = "111";
} else if ($designation == "Manager") {
  $admin_code = "999";
}

// Insert employee data into database
$sql = "INSERT INTO Employee (firstname, lastname, email, telephone, sin, password, designation, admin_code)
        VALUES ('$firstname', '$lastname', '$email', '$telephone', '$sin', '$password', '$designation', '$admincode')";

if ($conn->query($sql) === TRUE) {
  echo "Employee account created successfully.";
} else {
  echo "Error creating employee account: " . $conn->error;
}

// Close database connection
$conn->close();

// Redirect to ViewAllEmployees.php page
header("Location: ViewAllEmployees.php");
exit;
?>
