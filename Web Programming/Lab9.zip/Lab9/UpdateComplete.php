<?php
$message = $_GET['message'];
if ($message === 'success') {
	echo "The employee's information has been updated successfully.";
} else {
	echo "There was an error updating the employee's information.";
}
?>
