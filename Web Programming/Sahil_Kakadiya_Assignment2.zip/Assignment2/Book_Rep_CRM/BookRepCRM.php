
<!DOCTYPE html>
<html lang="en">
<head>
   <meta http-equiv="Content-Type" content="text/html; 
   charset=UTF-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta name="description" content="">
   <meta name="author" content="">
   <title>Book Template</title>

   <link rel="shortcut icon" href="../../assets/ico/favicon.png">

   <!-- Google fonts used in this theme  -->
<link href='http://fonts.googleapis.com/css?family=Roboto+Slab:400,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic,700italic' rel='stylesheet' type='text/css'>  

   <!-- Bootstrap core CSS -->
   <link href="bootstrap3_bookTheme/dist/css/bootstrap.min.css" rel="stylesheet">
   <!-- Bootstrap theme CSS -->
   <link href="bootstrap3_bookTheme/theme.css" rel="stylesheet">


   <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
   <!--[if lt IE 9]>
   <script src="bootstrap3_bookTheme/assets/js/html5shiv.js"></script>
   <script src="bootstrap3_bookTheme/assets/js/respond.min.js"></script>
   <![endif]-->
</head>

<body>

<?php include 'book-header.inc.php'; ?>
   
<div class="container">
   <div class="row">  <!-- start main content row -->

      <div class="col-md-2">  <!-- start left navigation rail column -->
         <?php include 'book-left-nav.inc.php'; ?>
      </div>  <!-- end left navigation rail --> 

      <div class="col-md-10">  <!-- start main content column -->
        
         <!-- Customer panel  -->
         <div class="panel panel-danger spaceabove">           
           <div class="panel-heading"><h4>My Customers</h4></div>
           <table class="table">
             <tr>
               <th>Name</th>
               <th>Email</th>
               <th>University</th>
               <th>City</th>
             </tr>
            <?php
             $lines = file('customers.txt'); // read file into array

             foreach ($lines as $line) {
               $fields = explode(',', $line); // split line into fields using comma as delimiter
               $id = $fields[0];
               $name = $fields[1] . ' ' . $fields[2];
               $email = $fields[3];
               $university = $fields[4];
               $city = $fields[6];
               echo '<tr>';
               echo '<td><a href="BookRepCRM.php?id=' . $id . '">' . $name . '</a></td>';
               echo '<td>' . $email . '</td>';
               echo '<td>' . $university . '</td>';
               echo '<td>' . $city . '</td>';
               echo '</tr>';
             }
            ?>
           </table>
         </div> 
         
         <?php 
  if(isset($_GET['id'])){
    $customer_id = $_GET['id'];
    $orders = file('orders.txt'); // read file into array
    $matching_orders = array();

    // Loop through each line in the orders file and check if the customer id matches
    foreach ($orders as $order) {
      $fields = explode(',', $order); // split line into fields using comma as delimiter
      if($fields[1] == $customer_id){
        $isbn = $fields[2];
        $title = $fields[3];
        $category = $fields[4];
        $matching_orders[] = array($isbn, $title, $category);
      }
    }

    // Display the matching orders for the customer
    if(count($matching_orders) > 0){
      echo '<div class="panel panel-danger spaceabove">           
             <div class="panel-heading"><h4>Orders for customer ' . $customer_id . '</h4></div>
             <table class="table">
               <tr>
                 <th>ISBN</th>
                 <th>Title</th>
                 <th>Category</th>
               </tr>';
      foreach($matching_orders as $order){
        echo '<tr>
                <td>' . $order[0] . '</td>
                <td>' . $order[1] . '</td>
                <td>' . $order[2] . '</td>
              </tr>';
      }
      echo '</table></div>';
    } else {
      // No matching orders found
      echo '<div class="panel panel-danger spaceabove">           
             <div class="panel-heading"><h4>No orders found for customer ' . $customer_id . '</h4></div>
           </div>';
    }
  }
?>
         
               

      </div>


      </div>  <!-- end main content column -->
   </div>  <!-- end main content row -->
</div>   <!-- end container -->
   


   
   
 <!-- Bootstrap core JavaScript
 ================================================== -->
 <!-- Placed at the end of the document so the pages load faster -->
 <script src="bootstrap3_bookTheme/assets/js/jquery.js"></script>
 <script src="bootstrap3_bookTheme/dist/js/bootstrap.min.js"></script>
 <script src="bootstrap3_bookTheme/assets/js/holder.js"></script>
</body>
</html>

