<!DOCTYPE html>
<html>
<head>
</head>
<body>
  <?php
    include 'header.php';
    include 'menu.php';
  ?>
  <div>
      <div>
php
Copy code
  <?php
$currencies = array(
  "CAD" => "Canadian Dollar",
  "NZD" => "New Zealand Dollar",
  "USD" => "US Dollar"
);

$rates = array(
  "CAD" => 0.97645,
  "NZD" => 1.20642,
  "USD" => 1.0
);

$amount_input = '';
$src_curr = '';
$dest_curr = '';
$converted_output = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $amount_input = $_POST['srcamt'];
  $src_curr = $_POST['srccurr'];
  $dest_curr = $_POST['destcurr'];

  if (isset($rates[$src_curr]) && isset($rates[$dest_curr])) {
    $converted_output = ($amount_input/$rates[$src_curr]) * $rates[$dest_curr];
    $converted_output = number_format((float)$converted_output, 2, '.', '');
  }
}
?>

  <header>
    <h2>Currency Converter</h2>
  </header>
  <main>
    <form method="post">
      <label for="srcamt">Convert:</label>
      <input type="number" id="srcamt" name="srcamt" min="0" step="0.01" value="<?php echo $amount_input; ?>" required><br><br>
php
Copy code
  <label for="srccurr">Source currency:</label>
  <select id="srccurr" name="srccurr" required>
    <option value="">--Select Currency--</option>
    <?php foreach ($currencies as $code => $name) { ?>
      <option value="<?php echo $code ?>" <?php if ($src_curr == $code) { echo 'selected'; } ?>><?php echo $name ?></option>
    <?php } ?>
  </select><br><br>

  <label for="destcurr">Destination currency:</label>
  <select id="destcurr" name="destcurr" required>
    <option value="">--Select Currency--</option>
    <?php foreach ($currencies as $code => $name) { ?>
      <option value="<?php echo $code ?>" <?php if ($dest_curr == $code) { echo 'selected'; } ?>><?php echo $name ?></option>
    <?php } ?>
  </select><br><br>

  <button type="submit">Do It!</button>
</form>


  </div>
</div> 
 </div>
  <?php
    include 'footer.php';
  ?>
</body>
</html> 