<?php
$firstName = "Sahil";
$lastName = "Kakadiya";
define("Numbers","041052919")
?>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="StyleSheet.css" />
	</head>
<body>

<?php
	echo "<div id=\"footer\">
	<p> Name: ".$firstName." ".$lastName."</p>
	<p> Student Number: ",Numbers," <p> </br>
	</div>";
?>

</body>
</html>
