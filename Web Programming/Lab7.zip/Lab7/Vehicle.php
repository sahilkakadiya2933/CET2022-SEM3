<html>
	<head>
		<link rel="stylesheet" type="text/css" href="StyleSheet.css" />
	</head>
<body>
<?php
    include('Header.php'); 
    include('Menu.php');
?>

<?php

interface Vehicle {
    public function displayVehicleInfo();
}

class LandVehicle implements Vehicle {
    protected $make;
    protected $model;
    protected $year;
    protected $price;

    public function __construct($make, $model, $year, $price) {
        $this->make = $make;
        $this->model = $model;
        $this->year = $year;
        $this->price = $price;
    }

    public function displayVehicleInfo() {
        echo "Make: " . $this->make . ", Model: " . $this->model . ", Year: " . $this->year . ", Price: " . $this->price;
    }
}

class Car extends LandVehicle {
    private $speedLimit;

    public function __construct($make, $model, $year, $price, $speedLimit) {
        parent::__construct($make, $model, $year, $price);
        $this->speedLimit = $speedLimit;
    }

    public function displayVehicleInfo() {
        parent::displayVehicleInfo();
        echo ", Speed Limit: " . $this->speedLimit;
    }
}

class WaterVehicle implements Vehicle {
    protected $make;
    protected $model;
    protected $year;
    protected $price;

    public function __construct($make, $model, $year, $price) {
        $this->make = $make;
        $this->model = $model;
        $this->year = $year;
        $this->price = $price;
    }

    public function displayVehicleInfo() {
        echo "Make: " . $this->make . ", Model: " . $this->model . ", Year: " . $this->year . ", Price: " . $this->price;
    }
}

class Boat extends WaterVehicle {
    private $boatCapacity;

    public function __construct($make, $model, $year, $price, $boatCapacity) {
        parent::__construct($make, $model, $year, $price);
        $this->boatCapacity = $boatCapacity;
    }

    public function displayVehicleInfo() {
        parent::displayVehicleInfo();
        echo ", Boat Capacity: " . $this->boatCapacity;
    }
}

// Instantiate at least two objects of Car and display the properties of each object instance
$car1 = new Car("Toyota", "Camry", 1992, 2000, 180);
$car2 = new Car("Honda", "Accord", 2002, 6000, 200);

echo "Car<br>";
echo "Car1: ";
$car1->displayVehicleInfo();
echo "<br>Car2: ";
$car2->displayVehicleInfo();
echo "<br>";

// Instantiate at least two objects of Boat and display the properties of each object instance
$boat1 = new Boat("Mitsubishi", "Turbo", 1999, 20000, 18);
$boat2 = new Boat("Hyundai", "XT", 2012, 26000, 8);

echo "<br>Boat<br>";
echo "Boat1: ";
$boat1->displayVehicleInfo();
echo "<br>Boat2: ";
$boat2->displayVehicleInfo();

?>

<?php
    include('Footer.php');
?>
</body>
</html>