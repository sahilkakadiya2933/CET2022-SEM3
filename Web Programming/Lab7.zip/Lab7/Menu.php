<!DOCTYPE html>
<html>
<body>

<?php
	echo '<a href ="product.php">Product</a><br><br>';
    echo '<a href ="Currency.php">Currency</a><br><br>';
    echo '<a href ="Vehicle.php">Vehicle</a><br>';
?>

</body>
</html>
