<html>
	<head>
		<link rel="stylesheet" type="text/css" href="StyleSheet.css" />
	</head>
<body>
<?php
    include('Header.php'); 
    include('Menu.php');
?>
<?php
			// create and initialize the $Product array
			$Product = array(
				"<u>Printer</u>" => array(
					array("Brand" => "Epson", "Quantity" => 100, "Price" => 2500),
					array("Brand" => "Canon", "Quantity" => 100, "Price" => 3000),
					array("Brand" => "Xerox", "Quantity" => 500, "Price" => 2000)
				),
				"<u>Laptop</u>" => array(
					array("Brand" => "Apple", "Quantity" => 200, "Price" => 2000),
					array("Brand" => "HP", "Quantity" => 300, "Price" => 1500),
					array("Brand" => "Toshiba", "Quantity" => 100, "Price" => 1200)
				),
				"<u>TV</u>" => array(
					"Samsung", "LG", "Sony"
				)
			);

			// display the structure of the $Product array
			var_dump($Product);
			?>
			<br>
			<hr>

<?php
// create and initialize the $Products array
$Products = array(
    "Printer" => array(
        array("Brand" => "Epson", "Quantity" => 100, "Price" => 2500),
        array("Brand" => "Canon", "Quantity" => 100, "Price" => 3000),
        array("Brand" => "Xerox", "Quantity" => 500, "Price" => 2000)
    ),
    "Laptop" => array(
        array("Brand" => "Apple", "Quantity" => 200, "Price" => 2000),
        array("Brand" => "HP", "Quantity" => 300, "Price" => 1500),
        array("Brand" => "Toshiba", "Quantity" => 100, "Price" => 1200)
    ),
    "TV" => array(
        array("Brand" => "Samsung", "Quantity" => 500, "Price" => 1200),
        array("Brand" => "LG", "Quantity" => 500, "Price" => 1050),
        array("Brand" => "Sony", "Quantity" => 200, "Price" => 1000)
    )
);

// display the elements of the $Products array using a foreach loop
foreach ($Products as $category => $brands) {
    echo "<u>" . $category . "</u><br>"; // display the category name in bold
    
    foreach ($brands as $brand) {
        // display the brand name, quantity, and price for each product
        echo "Brand: " . $brand["Brand"] . " Quantity: " . $brand["Quantity"] . " Price: " . $brand["Price"] . "<br>";
    }
    echo "<br>";
}
?>
<br>
<br><hr>
<?php

// display the elements of the $Products array in a table format
echo "<table style='border: 2px solid black;'>";
echo "<tr><th style='border: 2px solid black;'>Category</th><th style='border: 1px solid black;'>Brand</th><th style='border: 1px solid black;'>Quantity</th><th style='border: 1px solid black;'>Price</th></tr>";

foreach ($Products as $category => $brands) {
    foreach ($brands as $brand) {
        // display the category name only for the first brand in the category
        if ($brand == reset($brands)) {
            echo "<tr><td style='border: 2px solid black;' rowspan='" . count($brands) . "'>" . $category . "</td><td style='border: 2px solid black;'>" . $brand["Brand"] . "</td><td style='border: 1px solid black;'>" . $brand["Quantity"] . "</td><td style='border: 1px solid black;'>" . $brand["Price"] . "</td></tr>";
        } else {
            echo "<tr><td style='border: 2px solid black;'>" . $brand["Brand"] . "</td><td style='border: 2px solid black;'>" . $brand["Quantity"] . "</td><td style='border: 1px solid black;'>" . $brand["Price"] . "</td></tr>";
        }
    }
}

echo "</table>";
?>


echo "</table>";
?>
<?php
    include('Footer.php');
?>
</body>
</html>
