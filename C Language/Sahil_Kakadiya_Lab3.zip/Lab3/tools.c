/*@author: Surbhi Bahri*/

#include "tools.h"
#include "defs.h"

void deleteFile(char *fileName) {
  /* file name */
  printf("file deleted\n");
}

void processInput(char *input) {
  /* prcess input */
  printf("Input processed\n");
}

void saveFile(char *fileName, char *path) {
  /* save File */
  printf("file saved\n");
}
