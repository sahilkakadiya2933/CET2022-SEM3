/*@author: Surbhi Bahri*/
#ifndef users_h
#define users_h

#include <stdio.h>

char* username( void );

#endif /* users_h */

