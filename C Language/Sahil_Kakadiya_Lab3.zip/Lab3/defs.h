/*@author: Surbhi Bahri*/
#ifndef defs_h
#define defs_h

#include <stdio.h>

#define COPY_COMMAND 1001
#define CUT_COMMAND 1002
#define PASTE_COMMAND 1003

#endif /* defs_h */

