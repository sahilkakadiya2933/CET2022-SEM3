/*@author: Surbhi Bahri*/
#ifndef commands_h
#define commands_h

#include <stdio.h>

int canCopy(void);
int canCut(void);
int canPaste(void);

#endif /* commands_h */

