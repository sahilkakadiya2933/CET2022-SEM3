/*@author: Surbhi Bahri*/
#ifndef tools_h
#define tools_h

#include <stdio.h>

void deleteFile(char *);
void processInput(char *);
void saveFile(char *, char *);

#endif /* tools_h */

