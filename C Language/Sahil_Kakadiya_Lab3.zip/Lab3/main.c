/*@author: Surbhi Bahri*/

#include <stdio.h>
#include <stdlib.h>

#include "commands.h"
#include "tools.h"
#include "users.h"

int main(int argc, const char *argv[]) {

  if (canCopy()) {
    processInput("user input");
    char *userName = username();
    printf("Well done, you've compiled and run the program correctly %s\n",
           userName);
  }

  return EXIT_SUCCESS;
}
