#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#define MAX_EMPLOYEES 100

struct Employee {
    char name[50];
    char gender;
    int age;
    char job_profile[50];
};

extern struct Employee database[MAX_EMPLOYEES];
extern int num_employees;

void insert_employee();
void modify_employee();
void delete_employee();
void show_employees();

#endif
