#include <stdio.h>
#include <string.h>
#include "employee.h"

struct Employee database[MAX_EMPLOYEES];
int num_employees = 0;

void insert_employee() {
    if (num_employees >= MAX_EMPLOYEES) {
        printf("Database full\n");
        return;
    }

   printf("Enter name: ");
    getchar();
    int i = 0;
    char c;
    while ((c = getchar()) != '\n') {
        database[num_employees].name[i] = c;
        i++;
    }
    
 
    

    printf("Enter gender: ");
    scanf(" %c", &database[num_employees].gender);

    printf("Enter age: ");
    scanf("%d", &database[num_employees].age);

    printf("Enter job profile: ");
    getchar(); // consume the newline character left in the input buffer
    i = 0;
    while ((c = getchar()) != '\n') {
        database[num_employees].job_profile[i] = c;
        i++;
    }
    database[num_employees].job_profile[i] = '\0';

    printf("Newly Added Employee Information: %s %c %d %s\n",
           database[num_employees].name, database[num_employees].gender,
           database[num_employees].age, database[num_employees].job_profile);

    num_employees++;
}


    
void modify_employee() {
    char feature[50];
    printf("Enter the employee feature you wish to modify:\n");
    printf("You entered: ");
    scanf("%s", feature);

     int employee_index = -1;
    char employee_name[50];
    char new_job_profile[50];
    char employee_gender;
    int employee_age;

    if (strcmp(feature, "name") == 0) {
        printf("Enter the name of the employee you wish to change:\n");
        getchar(); // consume the newline character left in the input buffer
        int i=0;
        char c;
        
        while ((c = getchar()) != '\n') {
           
            employee_name[i] = c;
            i++;
        }
        employee_name[i] = '\0';
        
         for (int i = 0; i < num_employees; i++) {
        if (strcmp(database[i].name, employee_name) == 0) {
            employee_index = i;
            break;
        }
    }

    if (employee_index == -1) {
        printf("Employee not found\n");
        return;
    }
        

        printf("Enter the new name:\n");
     // consume the newline character left in the input buffer
        i = 0;
        while ((c = getchar()) != '\n') {
           
            database[employee_index].name[i] = c;
            i++;
        }
        database[employee_index].name[i] = '\0';

       strcpy(employee_name, database[employee_index].name);
    }
    
    else if (strcmp(feature, "gender") == 0) {
        printf("Enter the current gender of the employee: ");
        scanf(" %c", &employee_gender);
        for (int i = 0; i < num_employees; i++) {
            if (database[i].gender == employee_gender) {
                employee_index = i;
                break;
            }
        }
        if (employee_index == -1) {
            printf("Employee not found\n");
            return;
        }

        printf("Enter the new gender (M/F/O): ");
        scanf(" %c", &database[employee_index].gender);
    }
    else if (strcmp(feature, "age") == 0) {
        printf("Enter the current age of the employee: ");
        scanf("%d", &employee_age);
        for (int i = 0; i < num_employees; i++) {
            if (database[i].age == employee_age) {
                employee_index = i;
                break;
            }
        }
        if (employee_index == -1) {
            printf("Employee not found\n");
            return;
        }

        printf("Enter the new age: ");
        scanf("%d", &database[employee_index].age);
    }
    else if (strcmp(feature, "job profile") == 0) {
        printf("Enter the name of the employee: ");
        scanf("%s", employee_name);
        for (int i = 0; i < num_employees; i++) {
            if (strcmp(database[i].name, employee_name) == 0) {
                employee_index = i;
                break;
            }
        }
        if (employee_index == -1) {
            printf("Employee not found\n");
            return;
        }

        printf("Enter the new job profile: ");
        getchar(); // consume the newline character left in the input buffer
        int i = 0;
        char c;
        while ((c = getchar()) != '\n') {
            new_job_profile[i] = c;
            i++;
        }
        new_job_profile[i] = '\0';

        strcpy(database[employee_index].job_profile, new_job_profile);
    }
    else {
        printf("Invalid feature\n");
        return;
    }

    printf("Modified Employee Information: %s %c %d %s\n",
        database[employee_index].name, database[employee_index].gender,
        database[employee_index].age, database[employee_index].job_profile);

}


void delete_employee() {
    char employee_name[50];
    printf("Enter the employee feature (name, gender, age, profile) you wish to delete:\n");
    getchar(); // consume the newline character left in the input buffer
    int i = 0;
    char c;
    while ((c = getchar()) != '\n') {
        employee_name[i] = c;
        i++;
    }
    employee_name[i] = '\0';

    int employee_index = -1;
    for (int i = 0; i < num_employees; i++) {
        if (strcmp(database[i].name, employee_name) == 0) {
            employee_index = i;
            break;
        }
    }

    if (employee_index == -1) {
        printf("Employee not found\n");
        return;
    }
    
    
    printf("Is this the employee you wish to discard from database? Please conform  (Y/N):\n ");
    printf("%s ", database[employee_index].name);
    printf("%c ", database[employee_index].gender);
    printf("%d ", database[employee_index].age);
    printf("%s\n", database[employee_index].job_profile);
    printf("You entered: ");
    char confirm;
    scanf(" %c", &confirm);
    if (confirm == 'Y' || confirm == 'y') {
        for (int i = employee_index; i < num_employees - 1; i++) {
            database[i] = database[i + 1];
        }
        num_employees--;
        printf("Employee name %s deleted successfully\n",database[employee_index].name);
    }
}



void show_employees() {
printf("Total number of employees: %d\n", num_employees);
for (int i = 0; i < num_employees; i++) {
printf("%s %c %d %s\n",
database[i].name, database[i].gender,
database[i].age, database[i].job_profile);
}
}

int main() {
    printf("Choose one of the following options\n"
           "[1] Insert data of another employee\n"
           "[2] Modify existing employee information\n"
           "[3] Delete an employee's data\n"
           "[4] Shows all database entries\n"
           "[a] To quit\n");

    char option[10];

    do {
        printf("You pressed: ");
        scanf("%s", option);


        if (strcmp(option, "1") == 0) {

            insert_employee();
        }

        else if (strcmp(option, "2") == 0) {

            modify_employee();

        }
        else if (strcmp(option, "3") == 0) {
            
            delete_employee();

        }
        else if (strcmp(option, "4") == 0) {

            show_employees();

        }
        else if (strcmp(option, "a") == 0 || strcmp(option, "A") == 0) {

            printf("Have a nice time!\n");
            return 0;

        }

        else{

            printf("Not accepted. Enter a valid option number [1-4 or a]\n");

        }


        printf("What would you like to do next? \n");
        // consume any remaining characters in the input buffer
    } while (1);

    return 0;
}