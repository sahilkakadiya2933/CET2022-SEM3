#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define MAX_STUDENTS 100
#define MAX_COURSES 100
#define MAX_ID_LENGTH 6
#define COURSE_ID_LENGTH 8
struct student {
    int id;
};
struct course {
    char id[8];
    char registration_status;
    struct student students[MAX_STUDENTS];
    int num_students;
};


// this function display the list of available course
void displayStudentIds(int student_ids[MAX_STUDENTS], int num_students) {
    printf("List of Student Ids\n");
    for (int i = 0; i < num_students; i++) {
        printf("Index %d\t\t%d\n", i, student_ids[i]);
    }
}

// this fuction display the list of course id
void displayCourseIds(char course_ids[MAX_COURSES][COURSE_ID_LENGTH], int num_courses) {
    printf("List of Available Course Ids\n");
    for (int i = 0; i < num_courses; i++) {
        printf("Index %d\t\t%s\n", i, course_ids[i]);
    }
}

// this function implements if a course is full
int isCourseFull(int courseRegistrations[MAX_COURSES], int courseCapacity[MAX_COURSES], int courseIdIndex) {
    if (courseRegistrations[courseIdIndex] >= courseCapacity[courseIdIndex]) {
        printf("Error: Course %d is already full.\n", courseIdIndex);
        return 1;
    }
    return 0;
}


// Function to register a student into a course
void register_student(struct course courses[], int num_courses) {
    int course_index;
    printf("\nEnter the Student's ID to register a course: ");
    int student_id;
    scanf("%d", &student_id);

    // Find the course to register the student into
    printf("\nList of Available Course IDs\n");
    for (int i = 0; i < num_courses; i++) {
        printf("Index %d: %s\n", i, courses[i].id);
    }
    printf("Enter the course ID [3-Alphas] [4-digits]: ");
    char course_id[COURSE_ID_LENGTH];
    scanf("%s", course_id);
    for (int i = 0; i < num_courses; i++) {
        if (strcmp(courses[i].id, course_id) == 0) {
            course_index = i;
            break;
        }
    }

    // Register the student into the course
    if (courses[course_index].num_students < MAX_STUDENTS) {
        courses[course_index].students[courses[course_index].num_students].id = student_id;
        courses[course_index].num_students++;
        courses[course_index].registration_status = 'R';
} else {
printf("Course is full");
}
}

// Function to drop a student from a course
void drop_student(struct course courses[], int num_courses) {
int course_index;
printf("\nEnter the Student's ID to drop a course: ");
int student_id;
scanf("%d", &student_id);


// Find the course from which to drop the student
printf("\nList of Available Course IDs\n");
for (int i = 0; i < num_courses; i++) {
    printf("Index %d: %s\n", i, courses[i].id);
}
printf("Enter the course ID [3-Alphas] [4-digits]: ");
char course_id[8];
scanf("%s", course_id);
for (int i = 0; i < num_courses; i++) {
    if (strcmp(courses[i].id, course_id) == 0) {
        course_index = i;
        break;
    }
}

// Drop the student from the course
for (int i = 0; i < courses[course_index].num_students; i++) {
    if (courses[course_index].students[i].id == student_id) {
        // Replace the student with the last student in the array
        courses[course_index].students[i] = courses[course_index].students[courses[course_index].num_students - 1];
        courses[course_index].num_students--;
        courses[course_index].registration_status = 'D';
        printf("Student Dropped Successfully\n");
        return;
    }
}

// If the function has not yet returned, the student was not found
printf("Student not found in course.\n");
}

void display_registration_table(struct course courses[], int num_courses) {
    printf("\nRegistration Table\n");
    for (int i = 0; i < num_courses; i++) {
        printf("Course ID: %s\t", courses[i].id);
        printf("Registration Status: %c\t", courses[i].registration_status);
        printf("Index\tStudent ID\t");
        for (int j = 0; j < courses[i].num_students; j++) {
            printf("%d\t%d\n", j, courses[i].students[j].id);
        }
    }
}

// Function to register a student into a course





int main() {
    int num_students,num_courses,courseRegistrations[MAX_COURSES],studentId, courses;
    int courseCapacity[MAX_COURSES],courseIdIndex;
    char course_ids[MAX_COURSES][COURSE_ID_LENGTH];
    _Bool registrations[MAX_STUDENTS][MAX_COURSES];
    char courseId[COURSE_ID_LENGTH];
     // Initialize all elements to 0

    printf("Welcome to Student Registration System.\n");

    printf("Enter the number of students to register: ");
    scanf("%d", &num_students);

    int student_ids[MAX_STUDENTS];
    int i = 0;

    do {

        printf("Enter the Student index[%d] student id [%d-digits]: ", i, MAX_ID_LENGTH - 1);
        scanf("%d", &student_ids[i]);

        // Check if the input is a 5-digit number
        do {
            if (student_ids[i] < 10000 || student_ids[i] > 99999) {
                printf("Student id must be %d digits\n", MAX_ID_LENGTH - 1);
                printf("Enter the Student index[%d] student id [%d-digits]: ", i, MAX_ID_LENGTH - 1);
                scanf("%d", &student_ids[i]);
            }
        } while (student_ids[i] < 10000 || student_ids[i] > 99999);

        i++;
    } while (i < num_students);

    printf("Enter the number of courses available: ");
    scanf("%d", &num_courses);



    do {
        for(int i = 0; i< num_courses; i++){
        printf("Enter the course index[%d] course id [3-Alphas][4-digits]: ", i);
        scanf("%s", course_ids[i]);

        // Check if the input has correct length
        int input_length = strlen(course_ids[i]);
        do {

        } while (input_length != 7);

        // Check if the input has correct format
        int j = 0;
        do {
            if (input_length != 7) {
                printf("Incorrect Course Id length [7-character Id]\n");
                printf("Enter the course index[%d] course id [3-Alphas][4-digits]: ", i);
                scanf("%s", course_ids[i]);
                input_length = strlen(course_ids[i]);
            }
            else if (j < 3 && (course_ids[i][j] < 'a' || course_ids[i][j] > 'z')) {
                printf("Incorrect Course Id input [3-Alpha][4-digits]\n");
                printf("Enter the course index[%d] course id [3-Alphas][4-digits]: ", i);
                scanf("%s", course_ids[i]);
                j = 0;
            } else if (j >= 3 && (course_ids[i][j] < '0' || course_ids[i][j] > '9')) {
                printf("Incorrect Course Id input [3-Alpha][4-digits]\n");
                printf("Enter the course index[%d] course id [3-Alphas][4-digits]: ", i);
                scanf("%s", course_ids[i]);
                j = 0;
            }

             else {
                j++;
            }
        } while (j < 7);

    }
    } while (i < num_courses);

     int choice;

    do {
        // Display the menu options
        puts("");
        printf("Main Menu:\n");
        printf("[1] Register a student into a course\n");
        printf("[2] Drop a student from a course\n");
        printf("[3] Display Register Table\n");
        printf("[4] Exit\n");
        printf("Enter the option from the menu: ");
        scanf("%d", &choice);

        // Code to perform the selected menu option
        switch (choice) {
            case 1:{

                // Code to register a student into a course
                displayStudentIds(student_ids, num_students);
                printf("Enter the Student’s Id to register a course: ");
                scanf("%d", &studentId);
                displayCourseIds(course_ids, num_courses);
                printf("Enter the course Id [3-Alphas][4-digits]: ");
                scanf("%s", courseId);
                 if (isCourseFull(courseRegistrations, courseCapacity, courseIdIndex)) {
                return;
                }

                // Register the student in the course
                courseRegistrations[courseIdIndex]++;
                printf("Registration Successful\n");

                break;
        }
                case 2:
                {
                    drop_student(courses, num_courses);
                    break;
                }
        case 3:
            {
                display_registration_table(courses, num_courses);
                break;
            }



        case 4:
            {
            printf("Exiting program...\n");
            break;
            }

        default:
                printf("Invalid option. Please enter a valid option.\n");

    }
    }
     while (choice != 4);


}
