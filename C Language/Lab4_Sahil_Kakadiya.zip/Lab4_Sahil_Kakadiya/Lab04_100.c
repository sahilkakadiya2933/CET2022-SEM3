#include <stdio.h>
#include <stdlib.h>

#define SIZE 100

void doors_state(char a[]);
int toggle_door(char a[]);

int main() {
    char doors[SIZE] = {0};

    toggle_door(doors);
    doors_state(doors);

    return EXIT_SUCCESS;
}

int toggle_door(char a[]) {
    for (int i = 1; i <= SIZE; i++) {
        for (int j = i - 1; j < SIZE; j += i) {
            a[j] ^= 1;
        }
    }
    return 0;
}

void doors_state(char a[]) {
    for (int i = 0; i < SIZE; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");
}
